
export default function SignUp() {
    return (
      <div>
        <h1>Sign up</h1>
      </div>
    );
  }
  