import React from 'react'
import Hero from "./Hero"
import ShoppingCart from './shopingCart/page'

const Shop = () => {
  return (
    <div>
      <Hero />
      <ShoppingCart />
    </div>
  )
}

export default Shop
