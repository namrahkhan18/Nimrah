import React from 'react'
import HomePage from './HomePage/page'

const Home = () => {
  return (
    <div>
    <HomePage />
    </div>
  )
}

export default Home
